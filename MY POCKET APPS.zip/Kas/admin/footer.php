<div id="footer">
			<div class="table-responsive">
			<table class="table table-striped table-bordered table-hover">
				<thead>
					<tr>
					<tr bgcolor='#9ACD32' align='center'>
					<th><p>&copy;  My Money Activity - <?php echo date("Y");?><br/>
					Komputerisasi Akuntansi STMIK AKAKOM </p></th>
					</tr>
				</thead>
				</table>
</div>
